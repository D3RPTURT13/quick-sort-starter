
public class QuickSorter {
	
	private int array[];
    private int length;
 
    public void sort(int[] inputArr) {
         //like the title says
        if (inputArr == null || inputArr.length == 0) {
            return;
        }
        this.array = inputArr;
        length = inputArr.length;
        quickSort(0, length - 1);
    }
 
    private void quickSort(int lo, int hi) {
        ///the main quick sort stuffs.....and nothing more 
        int i = lo;
        int j = hi;
       
        int pivot = array[lo+(hi-lo)/2];
       
        while (i <= j) {
           
            while (array[i] < pivot) {
                i++;
            }
            while (array[j] > pivot) {
                j--;
            }
            if (i <= j) {
                exchangeNumbers(i, j);
                i++;
                j--;
            }
        }
        if (lo < j)
            quickSort(lo, j);
        if (i < hi)
            quickSort(i, hi);
    }
 
    private void exchangeNumbers(int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
     
    public static void main(String a[]){
         //this be the tester boi (sorry......i'm bored)
        QuickSorter sorter = new QuickSorter();
        int[] input = {24,2,45,20,56,75,2,56,99,53,12};//modify this for different stuffs to sort the thingies
        sorter.sort(input);
        for(int i:input){
            System.out.print(i);
            System.out.print(" ");
        }
    }

	
}
//done, YAYYYY!
